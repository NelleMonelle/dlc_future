local Lib = {}

function Lib:init()
    print("Thank you for using the WorldCutscene Convenience Pack by AcousticJamm.")
end

return Lib
